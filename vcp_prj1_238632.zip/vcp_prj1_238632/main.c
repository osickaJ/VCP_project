#include <stdio.h>
#include <complex.h>
#include <string.h>
#include <stdlib.h>
#include <ctype.h>

int parse_complex(const char* str, double* real, double* imag) {
    char* end;

    // Initialize real and imaginary parts
    *real = 0.0;
    *imag = 0.0;

    if (strcmp(str, "i") == 0)
    {
        *imag = 1.0;
        return 0;
    }
    else if (strcmp(str,"-i") == 0)
    {
        *imag = -1.0;
        return 0;
    }
    else
    {
        *real = strtod(str, &end);
        if (end == str) {
            return 2; // No valid conversion
        }
        else if (*end == '\0')
        {
            *imag = 0.0;
            return 0;
        }
        else if((*end == '+') || (*end == '-'))
        {
            if (*(end+1) == 'i')
            {
                if (*end == '+') {
                    *imag = 1.0;
                    return 0;
                }
                else
                {
                    *imag = -1.0;
                    return 0;
                }
                end += 2;
            }
            else {
                str = end;
                *imag = strtod(str, &end);
                if (end == str) {
                    return 2;
                }
                if (*end != 'i') {
                    return 2;
                }
                end++;
            }
        }
        else if(*end == 'i')
        {
            *imag = *real;
            *real = 0.0;
            end++;
        }
        else
        {
            return 2;
        }
        if(*end != '\0') {
            return 2;
        }
    }
    return 0;
}
double absol(const double n) {
    if (n>=0) {
        return n;
    }else {
        return -n;
    }
}
double square_root(const double x) {
    int max_iter = 1000;
    int iter = 0;
    double sol = x/2.0;
    double guess;
    do {
        iter++;
        guess = sol;
        sol = 0.5*(guess + x/guess);
        if (iter > max_iter) {
            fprintf(stderr,"Infinite cycle");
            return 4;
        }
    } while (absol(guess-sol)> 1e-5);
    return sol;
}
char sign(double k) {
    if (k < 0) {
        return '-';
    } else {
        return '+';
    }
}
int mandelbrot(double complex z,const int iter, double* amplitude) {
    double complex c = z;
    int belongs = 1;
    for (int i = 0;i < iter; i++) {
        z = z*z+c;
    }
    *amplitude = cabs(z);
    if (cabs(z) > 2.0) {
        belongs = 0;
    }
    return belongs;
}
double dot_product(double* vector1, int size1, double* vector2, int size2) {
    if (size1 != size2) {
        fprintf(stderr, "Vectors must have same length.\n");
        return 4;
    }

    double product = 0;
    for (int i = 0; i < size1; i++) {
        product += vector1[i] * vector2[i];
    }
    return product;
}
int max_vec_size = 100;
int load_vec(const char* filename, double** vec1, int* size1, double** vec2, int* size2) {
    FILE* file;

    if (filename != NULL) {
        file = fopen(filename, "r");
        if (!file) {
            fprintf(stderr, "Could not open the file\n");
            return 3;
        }
    }
    else {
        file = stdin;
        printf("Input vectors:\n");
    }
    *vec1 = calloc(max_vec_size, sizeof(double));
    *vec2 = calloc(max_vec_size, sizeof(double));
    *size1 = 0;
    *size2 = 0;
    char line[256];
    if (fgets(line, sizeof(line), file) != NULL) {
        char* token = strtok(line, " ");
        while (token != NULL && *size1 < max_vec_size) {
            char* end;
            double coordinate = strtod(token, &end);
            if (*end != '\0' && !isspace(*end)) {
                fprintf(stderr, "Invalid input,elements of vector must be numbers.\n", token);
                return 1;
            }
            (*vec1)[*size1] = coordinate;
            (*size1)++;
            token = strtok(NULL, " ");
        }
    }
    else {
        fprintf(stderr, "Could not load the first vector.\n");
        if (filename != NULL) fclose(file);
        return 4;
    }
    if (fgets(line, sizeof(line), file) != NULL) {
        char* token = strtok(line, " ");
        while (token != NULL && *size2 < max_vec_size) {
            char* end;
            double coordinate = strtod(token, &end);
            if (*end != '\0' && !isspace(*end)) {
                fprintf(stderr, "Invalid input,elements of vector must be numbers.\n", token);
                return 1;
            }
            (*vec2)[*size2] = coordinate;
            (*size2)++;
            token = strtok(NULL, " ");
        }
    }
    else {
        fprintf(stderr, "Could not load the second vector.\n");
        if (filename != NULL) fclose(file);
        return 4;
    }
    if (filename != NULL) fclose(file);
    return 0;
}

int main(int argc, char* argv[]) {
    if (argc < 2) {
        fprintf(stderr, "No function specified.\n");
        return 1;
    }
    if (strcmp(argv[1], "sqrt") == 0) {
        if (argc != 3) {
            fprintf(stderr, "Invalid number of arguments.\n");
            return 2;
        }
        double z_real, z_imag;
        int result = parse_complex(argv[2], &z_real, &z_imag);
        if (result == 0) {
            if (z_imag == 0.0) {
                double sqrt_real = square_root(absol(z_real));
                if (z_real < 0) {
                    printf("Square root of %lf is:\n %.17lfi\n", z_real, sqrt_real);
                    printf("-%.17lfi", sqrt_real);
                } else {
                    printf("Square root of %lf is:\n %.17lf\n", z_real, sqrt_real);
                    printf("%.17lf", -sqrt_real);
                }
            }
            else {
                double magnitude = square_root(z_real * z_real + z_imag * z_imag);
                double sqrt_real = square_root((magnitude + z_real) / 2.0);
                double sqrt_imag = (z_imag >= 0 ? 1 : -1) * square_root((magnitude - z_real) / 2.0);
                char sign_imag = sign(z_imag);
                char sign_imag_sq = sign(sqrt_imag);
                printf("Square root of %lf %c %lfi is:\n %.17lf %c %.17lfi\n", z_real, sign_imag, absol(z_imag), sqrt_real,sign_imag_sq, absol(sqrt_imag));
                printf("%c%.17lf %c %.17lfi", sign(-sqrt_real), absol(sqrt_real), sign(-sqrt_imag), absol(sqrt_imag));
            }
        }else {
            fprintf(stderr, "Invalid input");
            return 2;
        }
    }
    else if (strcmp(argv[1], "mandelbrot") == 0) {
        int iter;
        double real, imag;
        if (argc == 2) {
            fprintf(stderr, "Invalid number of arguments.");
            return 2;
        }
        int result = parse_complex(argv[2], &real, &imag);
        if (result == 0) {
            if (argc == 4) {
                char *endptr;
                iter = strtol(argv[3], &endptr, 10);
                if (*endptr != '\0') {
                    fprintf(stderr, "Invalid number of iterations.");
                    return 2;
                }
            }else if (argc == 3) {
                iter = 75;
            }else {
                fprintf(stderr, "Invalid number of arguments.");
                return 2;
            }
            double complex z = real + imag * I;
            double amplitude;
            int belongs = mandelbrot(z, iter, &amplitude);
            printf("Belongs: %d\nAmplitude: %.17lf\n", belongs, amplitude);
        }
        else {
            fprintf(stderr, "Invalid input");
            return 2;
        }
    }
    else if (strcmp(argv[1], "dotprod") == 0) {
        const char* filename;
        if (argc == 2) {
            filename = NULL;
        } else if (argc == 3) {
            filename = argv[2];
        } else {
            fprintf(stderr, "Invalid number of arguments.");
            return 2;
        }
        double* vec1;
        double* vec2;
        int size1;
        int size2;
        int result = load_vec(filename, &vec1, &size1, &vec2, &size2);
        if (result == 0) {
            double product = dot_product(vec1, size1, vec2, size2);
            printf("Dot product: %.17lf", product);
            free(vec1);
            free(vec2);
        } else {
            return result;
        }


    } else {
        fprintf(stderr, "Function not found.");
        return 1;
    }
    return 0;
}

